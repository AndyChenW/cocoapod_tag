from setuptools import setup
 
setup(
     name='pod_tag', 
     version='0.2',  
     scripts=['pod_tag']
)

