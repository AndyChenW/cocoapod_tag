from setuptools import setup
 
setup(
     name='pod_tag', 
     version='0.1',  
     scripts=['pod_tag']
)

